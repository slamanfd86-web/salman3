﻿Public Class Form1
    Dim x, y, w, k As String
    Dim i As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        'حول المشروع
        w = Chr(13) + Chr(10)
        x = " سعود الملك جامعة " + w
        x = x + " مركز التدريب وخدمة المجتمع " + w
        x = x + " دبلوم الحاسب الآلي " + w
        x = x + " حذيفة عبدالرحمن الاستاذ إعداد " + w
        x = x + " ه 1442 الدراسي للعام "
        y = " المشروع حول "
        MsgBox(x, MsgBoxStyle.Information + MsgBoxStyle.MsgBoxRight, y)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

        ' خروج
        x = " ؟ المشروع من تريد الخروج هل "
        y = " تحذير "
        k = MsgBox(x, MsgBoxStyle.YesNo + MsgBoxStyle.Critical +
        MsgBoxStyle.MsgBoxRight, y)
        If k = 6 Then End

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs)
        ' الألوان إدخال صندوق
        i = InputBox("15 عدد بين الصفر و إدخال الرجاء ", " الإدخال صندوق ")
        'الخروج من الإجراء
        If i >= 0 And i <= 15 Then
            Me.BackColor = System.Drawing.ColorTranslator.FromOle(QBColor(Val(i)))
        Else
            MsgBox(" الادخال خاطئ ", , "تنبيه ")
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        'حول المشروع
        w = Chr(13) + Chr(10)
        x = " جامعه شبوة " + w
        x = x + " مركز التدريب وخدمة المجتمع " + w
        x = x + " تكنلويجا المعلومات " + w
        x = x + " اعداد سلمان  فدعق " + w
        x = x + " العام الدراسي 2025/2026"
        y = " المشروع حول "
        MsgBox(x, MsgBoxStyle.Information + MsgBoxStyle.MsgBoxRight, y)
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        ' خروج
        x = " هل تريد الخروج من المشروع "
        y = " تحذير "
        k = MsgBox(x, MsgBoxStyle.YesNo + MsgBoxStyle.Critical +
        MsgBoxStyle.MsgBoxRight, y)
        If k = 6 Then End
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        'الألوان إدخال صندوق
        i = InputBox("15 عدد بين الصفر و إدخال الرجاء ", " الإدخال صندوق ")
        'الخروج من الإجراء
        If i >= 0 And i <= 15 Then
            Me.BackColor = System.Drawing.ColorTranslator.FromOle(QBColor(Val(i)))
        Else
            MsgBox(" الادخال خاطئ ", , "تنبيه ")
        End If

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' أسطر عدة الكتابة على
        w = Chr(13) + Chr(10)
        TextBox1.Text = " لله الحمد " + w + " رب العالمين "
        Label1.Text = " الحمد لله " + w + " العالمين رب "
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click



        ' العشوئية الألوان
        Randomize()
        Me.BackColor = System.Drawing.ColorTranslator.FromOle(RGB(Rnd() *
255, Rnd() * 255, Rnd() * 255))255, Rnd() * 255, Rnd() * 255))
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        ' أسطر عدة الكتابة على
        w = Chr(13) + Chr(10)
        TextBox1.Text = " لله الحمد " + w + " رب العالمين "
        Label1.Text = " الحمد لله " + w + " العالمين رب "
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class
